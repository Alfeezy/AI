N-QUEENS GENETIC ALGORITHM:

Running instructions:

	1. Compile all files with >javac Chessboard.java ChessboardMain.java CO.java

	2. Run chessboard main as >java ChessboardMain [board size] [iterations]

	(All runs will be appended to the log file, in order clear log file, delete log.dat)

