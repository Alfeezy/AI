Welcome to the A* Pathfinding algorithm

RUNNING THE PROGRAM:

1. Compile all files with -javac AstarMain.java Location.java Road.java

2. Run AstarMain with -java AstarMain t

	where t an integer representing type of cost function:

	t = 1 : Distance dependent

	t = 2 : These merchants are hardened to snow, but quiver at the thought 
		Sauron's army. They are affected by risk level the most, followed
    		by road quality, and finally winter travel.

	t = 3 : These merchants have hired a crew of noble mercenaries to defend their
		precious cargo. They fear not of most attackers, but must be especially
		wary of poor road conditions, as their carriages are not very agile. 
		Winter is also of concern.